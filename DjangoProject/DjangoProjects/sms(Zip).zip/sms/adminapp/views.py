
import datetime
import time
import pytz
from django.shortcuts import render, redirect, get_object_or_404
from .models import Task
from .forms import TaskForm


def projecthomepage(request):
    return render(request,'adminapp/ProjectHomePage.html')

def printpagecall(request):
    return render(request,'adminapp/printer.html')
# Create your views here.
from django.shortcuts import render

def printpagelogic(request):
    user_input = None

    if request.method == "POST":
        user_input = request.POST.get('user_input', '')
        print(f'User input: {user_input}')

    context = {'user_input': user_input}
    return render(request, 'adminapp/printer.html', context)


def exceptionpagecall(request):
    return render(request,'adminapp/ExceptionExample.html')

def exceptionpagelogic(request):
    if request.method == "POST":
        user_input = request.POST['user_input']
        result = None
        error_message = None
        try:
            num=int(user_input)
            result=10/num
        except Exception as e:
            error_message = str(e)
        return render(request, 'adminapp/ExceptionExample.html',{'result': result,'error': error_message})
    return render(request,'adminapp/ExceptionExample.html')

import random
import string
def randompagecall(request):
    return render(request, 'adminapp/RandomExample.html')

def randompagelogic(request):
    if request.method == "POST":
        num1 = int(request.POST['num1'])
        ran = ''.join(random.sample(string.ascii_uppercase + string.digits, k=num1))
        a1 = {'ran': ran}
        return render(request, 'adminapp/RandomExample.html', a1)
    else:
        return render(request, 'adminapp/RandomExample.html')




def calculatorcall(request):
    return render(request, ' adminapp/CalculatorExample.html')
def calculatorlogic(request):
    result = None
    if request.method == 'POST':
        num1 = float(request.POST.get('num1'))
        num2 = float(request.POST.get('num2'))
        operation = request.POST.get('operation')

        if operation == 'add':
            result = num1 + num2
        elif operation == 'subtract':
            result = num1 - num2
        elif operation == 'multiply':
            result = num1 * num2
        elif operation == 'divide':
            result = num1 / num2 if num2 != 0 else 'Infinity'

    return render(request, 'adminapp/CalculatorExample.html', {'result': result})


def add_task(request):
    if request.method == 'POST':
        form = TaskForm(request.POST)
        if form.is_valid():
            form.save()
            return redirect('add_task')
    else:
        form = TaskForm()
    tasks = Task.objects.all()
    return render(request,'adminapp/add_task.html',{'form': form, 'tasks' : tasks})


def delete_task(request, pk):
    task = get_object_or_404(Task, pk=pk)
    task.delete()
    return redirect('add_task')



from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.contrib.auth.models import User
from django.contrib.auth import login, authenticate
from django.contrib.auth import logout
from django.urls import reverse



def register(request):
    if request.method == 'POST':
        username = request.POST['username']
        email = request.POST['email']
        password = request.POST['password']
        confirm_password = request.POST['confirm-password']

        if password == confirm_password:
            # Create the user and redirect to the homepage
            user = User.objects.create_user(username=username, email=email, password=password)
            login(request, user)
            messages.success(request, f'Account created for {username}!')
            return redirect('projecthomepage')
        else:
            messages.error(request, 'Passwords do not match')
            return redirect('register')
    else:
        return render(request, 'adminapp/register.html')


def user_login(request):
    if request.method == 'POST':
        username = request.POST['username']
        password = request.POST['password']

        # Authenticate the user
        user = authenticate(request, username=username, password=password)

        if user is not None:
            # Log the user in and redirect to homepage
            login(request, user)
            return redirect('projecthomepage')
        else:
            # Invalid credentials, show an error message
            error_message = "Invalid username or password"
            return render(request, 'adminapp/login.html', {'error_message': error_message})
    else:
        return render(request, 'adminapp/login.html')


def log_out(request):
    # Use Django's built-in logout function
    logout(request)

    # Redirect to a specific page after logging out (e.g., login page or homepage)
    return redirect(reverse('projecthomepage'))

from django.utils import timezone  # Import this at the top with other imports

def calculate_future_date(request):
    future_date = None
    if request.method == "POST":
        days_input = int(request.POST.get('days_input'))
        # Add the number of days to the current date
        current_time = timezone.now()  # Use timezone.now() to get the current time
        future_date = current_time + datetime.timedelta(days=days_input)

    return render(request, 'adminapp/DateTime.html', {'future_date': future_date})

def calculate_future_page(request):
    return render(request,'adminapp/DateTime.html')




def get_time_details(request):
    timezones = pytz.all_timezones
    timezone_time = None
    error_message = None
    timezone_name = None

    if request.method == 'POST':
        timezone_name = request.POST.get('timezone')
        try:
            # Get the current time in UTC
            utc_now = datetime.utcnow()

            # Convert UTC time to the selected timezone
            selected_timezone = pytz.timezone(timezone_name)
            timezone_time = utc_now.replace(tzinfo=pytz.utc).astimezone(selected_timezone)

            # Format the timezone_time for better readability (optional)
            timezone_time = timezone_time.strftime('%Y-%m-%d %H:%M:%S %Z%z')

        except pytz.UnknownTimeZoneError:
            error_message = "Invalid timezone selected. Please select a valid timezone."
        except Exception as e:
            error_message = f"An unexpected error occurred: {str(e)}"

    return render(request, 'adminapp/time.html', {
        'timezones': timezones,
        'timezone_time': timezone_time,
        'timezone_name': timezone_name,
        'error_message': error_message,
    })






